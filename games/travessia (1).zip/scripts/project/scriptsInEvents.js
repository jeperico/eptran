


const scriptsInEvents = {

	async FolhaDeEventos1_Event17(runtime, localVars)
	{
		
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

